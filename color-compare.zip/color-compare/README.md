# color compare

A Pen created on CodePen.

Original URL: [https://codepen.io/icomgroup/pen/myydVwm](https://codepen.io/icomgroup/pen/myydVwm).

